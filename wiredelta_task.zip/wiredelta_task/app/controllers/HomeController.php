<?php

class HomeController extends BaseController {
	
	public function indexForm() {

		$values = Sample::get();
		return View::make('pages.page',compact('values'));
	}
	public function AddForm() {

		return View::make('pages.add_page');
	}
	public function FormCreate() {
	
		$validator = Validator::make($data = Input::all(), Sample::$sample);
		if($validator->fails()) {
			return Redirect::back()->withErrors($validator)->withInput();
		} else {

			$value = new Sample;
			$value->textbox = $data['textbox'];
			$value->textarea = $data['textarea'];
			$value->email = $data['email'];
			$value->url = $data['url'];
			$value->number = $data['number'];
			$value->password = $data['password'];
			$value->conform_password = $data['conform_password'];
			$value->select = $data['select'];
			$value->check_box = $data['checkbox'];
			$value->radio = $data['radio'];
			$value->save();
			return Redirect::route('home')->with('form_added','form Successfully');
		}
	}
	public function EditForm($id) {

		$values = Sample::findOrfail($id);
		return View::make('pages.edit_page',compact('values'));
	}
	public function FormUpdate($id) {
	
		$value = Sample::findOrfail($id);
		$validator = Validator::make($data = Input::all(), Sample::$sample);
		if($validator->fails()) {
			return Redirect::back()->withErrors($validator)->withInput();
		} else {
			if($value) {	
				$value->textbox = $data['textbox'];
				$value->textarea = $data['textarea'];
				$value->email = $data['email'];
				$value->url = $data['url'];
				$value->number = $data['number'];
				$value->password = $data['password'];
				$value->conform_password = $data['conform_password'];
				$value->select = $data['select'];
				$value->check_box = $data['checkbox'];
				$value->radio = $data['radio'];
				$value->save();
				return Redirect::route('home')->with('form_updated','Form Updated Successfully');
			}
		}
	}
	public function Delete($id) {

		$pageDel = Sample::findOrFail($id)->delete();
		if($pageDel) {
			return Redirect::route('home')->with('form_deleted','Form Deleted Successfully');
		}
	}
	
}
