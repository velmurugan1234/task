<?php

class Sample extends \Eloquent {

	protected $fillable = [];
	public static $sample = array(
		'textbox' 			=> 'required | min:4 | max:10',
		'textarea' 			=> 'required | min:10 | max:255',
		'email' 			=> 'required | email',
		'url' 				=> 'required | url',
		'number' 			=> 'required | digits_between:4,10',
		'password' 			=> 'required | min:6 | max:10',
		'conform_password' 	=> 'required | same:password',
		'radio' 			=> 'required',
		'select' 			=> 'required',
		'checkbox' 			=> 'required',
	);
}