<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/

Route::get('/', array('as' => 'home','uses' => 'HomeController@indexForm'));
Route::get('/form/add', array('as' => 'form.add', 'uses' => 'HomeController@AddForm'));
Route::post('/form/add/save', array('as' => 'form.create', 'uses' => 'HomeController@FormCreate'));
//UPDATE
Route::get('/form/edit/{id}', array('as' => 'form.page', 'uses' => 'HomeController@EditForm'));
Route::post('/form/update/{id}', array('as' => 'form.update', 'uses' => 'HomeController@FormUpdate'));
//DELETE
Route::get('/form/delete/{id}', array('as' => 'form.delete', 'uses' => 'HomeController@Delete'));