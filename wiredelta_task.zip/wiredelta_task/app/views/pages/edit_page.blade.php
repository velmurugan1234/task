@include('partial.header')
<?php
$category = array(''=>'Select Option','Select1' => 'Value1','Select2' => 'Value2');
?>
<section class="wrapper">
	<div class="row">
      <div class="col-lg-12">
          <ol class="breadcrumb">
              <li><i class="fa fa-home"></i><a href="{{URL::to('/')}}">Form</a></li>
              <li><i class="fa fa-bars"></i>Edit</li>         
          </ol>
      </div>
  </div>
<!-- page start-->
  <h3 class="page-header"><i class="fa fa fa-bars"></i> Form</h3>
<!-- page end-->
</section>
<a href="{{URL::to('/')}}"><input type="submit" class="btn btn-success" value="Home" id="add"></a>
<hr />
<!--main content start-->
<section id="main-content">
 <div class="row">
      <div class="col-sm-10"> 
      {{Form::open(array('route' => ['form.update',$values->id],'role'=>'form','method'=>'POST'))}} 
          <div class="form-group">
              <label>Textbox</label>
                {{Form::input('text', 'textbox', $values->textbox, ['id' => 'name','class'=>'form-control','placeholder'=>'Enter Textbox Value'])}}
                {{$errors->first('textbox','<span class="error">* :message</span>')}}
          </div>
          <div class="form-group">
              <label>Textarea</label>
                {{Form::textarea('textarea', $values->textarea, ['id' => 'name','class'=>'form-control','placeholder'=>'Enter Textarea Value'])}}
                {{$errors->first('textarea','<span class="error">* :message</span>')}}
          </div>
          <div class="form-group">
              <label>Email</label>
                {{Form::input('text', 'email', $values->email, ['id' => 'name','class'=>'form-control','placeholder'=>'Enter Your Email'])}}
                {{$errors->first('email','<span class="error">* :message</span>')}}
          </div>
          <div class="form-group">
              <label>URL</label>
                {{Form::url('url', $values->url, ['id' => 'name','class'=>'form-control','placeholder'=>'Enter Your Url'])}}
                {{$errors->first('url','<span class="error">* :message</span>')}}
          </div>
          <div class="form-group">
              <label>Number</label>
                {{Form::input('number', 'number', $values->number, ['id' => 'name','class'=>'form-control','placeholder'=>'Enter Number'])}}
                {{$errors->first('number','<span class="error">* :message</span>')}}
          </div>
          <div class="form-group">
                {{Form::input('hidden', 'hidden', null, ['id' => 'name','class'=>'form-control','placeholder'=>''])}}
                {{$errors->first('hidden','<span class="error">* :message</span>')}}
          </div>
          <div class="form-group">
              <label>Password</label>
                {{Form::input('password', 'password', $values->password, ['id' => 'name','class'=>'form-control','placeholder'=>'Enter Password'])}}
                {{$errors->first('password','<span class="error">* :message</span>')}}
          </div>
          <div class="form-group">
              <label>Conform Password</label>
                {{Form::input('password', 'conform_password', $values->conform_password, ['id' => 'name','class'=>'form-control','placeholder'=>'Enter Conform Password'])}}
                {{$errors->first('conform_password','<span class="error">* :message</span>')}}
          </div>
          <div class="form-group">
              <label>Radio</label><br />
                  @if($values->radio == 'radio1')
                    {{-- */$checked='checked';/* --}}
                  @else
                    {{-- */$checked='';/* --}}
                  @endif
                <label>
                  {{Form::radio('radio','radio1',$checked, ['class'=>'flat-red'])}} radio1
                </label>
                  @if($values->radio == 'radio2')
                    {{-- */$checked='checked';/* --}}
                  @else
                    {{-- */$checked='';/* --}}
                  @endif
                <label>
                    {{Form::radio('radio','radio2',$checked, ['class'=>'flat-red'])}} radio2
                </label><br />
                {{$errors->first('radio','<span class="error">* :message</span>')}}
          </div>
          <div class="form-group">
              <label>Checkbox</label><br />
                  @if($values->check_box == 'value1')
                    {{-- */$checked='checked';/* --}}
                  @else
                    {{-- */$checked='';/* --}}
                  @endif
                <label>
                  {{Form::checkbox('checkbox','value1',$checked, ['class'=>'flat-red'])}} Checkbox1
                </label>
                  @if($values->check_box == 'value2')
                    {{-- */$checked='checked';/* --}}
                  @else
                    {{-- */$checked='';/* --}}
                  @endif
                <label>
                    {{Form::checkbox('checkbox','value2',$checked, ['class'=>'flat-red'])}} Checkbox2
                </label><br/>
                {{$errors->first('checkbox','<span class="error">* :message</span>')}}
          </div> 
          <div class="form-group">
              <label>Select</label>
                {{ Form::select('select',$category, $values->select,array('id' => 'category','class'=>'form-control')) }}
                {{$errors->first('select','<span class="error">* :message</span>')}}
          </div>
          <div class="form-group">
             {{ Form::submit('Save', array('class' => 'btn btn-success')) }}
                <a href="{{ URL::previous() }}">
                 <input type="button" value="Cancel" class="btn btn-danger">
                </a>
          </div>
        {{Form::close()}}
    </div>
  </div>
</section>
<!--main content end-->