@include('partial.header')
<section class="wrapper">
  <!-- page start-->
     <h3 class="page-header"><i class="fa fa fa-bars"></i> Form</h3>
  <!-- page end-->
</section>
<a href="{{URL::to('/')}}/form/add"><input type="submit" class="btn btn-success" value="Add New" id="add"></a>
 <hr />
  <!--main content start-->
 @if(Session::has('form_added'))
      <div class="alert alert-success alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <i class="icon fa fa-check"></i> Form Added Successfully
      </div>
 @endif
 @if(Session::has('form_updated'))
      <div class="alert alert-success alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <i class="icon fa fa-check"></i> Form Updated Successfully
      </div>
 @endif
 @if(Session::has('form_deleted'))
      <div class="alert alert-danger alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <i class="icon fa fa-check"></i> Form Deleted Successfully
      </div>
@endif
<section id="main-content">
  <div class="row">
    <div class="col-md-11">
        <section class="panel">
            <header class="panel-heading">
              Form Display
            </header>             
                <table id="example2" class="table table-bordered table-hover">
                  <thead>
                    <tr>
                      <th>S.No</th>
                      <th>Textbox</th>
                      <th>Textarea</th>
                      <th>Email</th>
                      <th>Url</th>
                      <th>Password</th>
                      <th>Radio</th>
                      <th>Check</th>
                      <th>Select</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                     @if (isset($values))
                       {{-- */$i=0;/* --}}
                     @foreach($values as $value)
                       {{-- */$i=$i+1;/* --}}
                  <tr>
                    <td>{{$i}}</td>
                    <td>{{$value->textbox}}</td>
                    <td>{{$value->textarea}}</td>
                    <td>{{$value->email}}</td>
                    <td>{{$value->url}}</td>
                    <td>{{$value->password}}</td>
                    <td>{{$value->radio}}</td>
                    <td>{{$value->check_box}}</td>
                    <td>{{$value->select}}</td>
                    <td>
                      <a href="{{URL::to('/')}}/form/edit/{{$value->id}}"><button type="button" class="btn btn-primary btn-xs" data-toggle="tooltip" title="Edit"><i class=""></i>Edit</button></a>
                      <a href="{{URL::to('/')}}/form/delete/{{$value->id}}"><button type="button" class="btn btn-danger btn-xs" data-toggle="tooltip" title="Delete"onClick="return confirm('Are You Sure Want to Delete')"><i class=""></i>Delete</button></a>
                    </td>
                  </tr>
                  @endforeach
                  @endif
                </tbody>
            </table>
        </section>
    </div>
  </div>
</section>
<!--main content end-->