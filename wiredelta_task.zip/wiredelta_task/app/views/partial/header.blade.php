<!DOCTYPE html>
<html lang="en" style="overflow: hidden;"><head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Creative - Bootstrap 3 Responsive Admin Template">
    <meta name="author" content="GeeksLabs">
    <meta name="keyword" content="Creative, Dashboard, Admin, Template, Theme, Bootstrap, Responsive, Retina, Minimal">
    <link rel="shortcut icon" href="img/favicon.png">

    <title>Interview Task</title>

    <!-- Bootstrap CSS -->    
    <link href="{{URL::to('/')}}/template/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- bootstrap theme -->
    <link href="{{URL::to('/')}}/template/dist/css/bootstrap-theme.css" rel="stylesheet">
    <!--external css-->
    <!-- font icon -->
    <link href="{{URL::to('/')}}/template/dist/css/elegant-icons-style.css" rel="stylesheet">
    <link href="{{URL::to('/')}}/template/dist/css/font-awesome.min.css" rel="stylesheet">
    <!-- Custom styles -->
    <link href="{{URL::to('/')}}/template/dist/css/style.css" rel="stylesheet">
    <link href="{{URL::to('/')}}/template/dist/css/style-responsive.css" rel="stylesheet">
  </head>

  <body>
  <!-- container section start -->
  <section id="container" class="">
      <!--header start-->
      
      <header class="header dark-bg">
            <div class="toggle-nav">
                <div class="icon-reorder tooltips" data-original-title="Toggle Navigation" data-placement="bottom"><i class="icon_menu"></i></div>
            </div>

            <!--logo start-->
            <a href="index.html" class="logo">Interview task <span class="lite"></span></a>
            <!--logo end-->

            <div class="collapse navbar-collapse pull-left" id="navbar-collapse">
              <ul class="nav navbar-nav">
                
               <!--  <li><a href="#">Dashboard</a></li>
                <li><a href="#">Users</a></li>
                <li><a href="#">Rooms</a></li>
                <li><a href="#">News</a></li> -->
                <!-- <li><a href="{{URL::to('/')}}/display">Display</a></li> -->
              </ul>  
            </div>          
      </header>      
      <!--header end-->
 
  </section>
  <!-- container section end -->
    <!-- javascripts -->
    <script src="{{URL::to('/')}}/template/dist/js/jquery.js"></script>
    <script src="{{URL::to('/')}}/template/dist/js/bootstrap.min.js"></script>
    <!-- nice scroll -->
    <script src="{{URL::to('/')}}/template/dist/js/jquery.scrollTo.min.js"></script>
    <script src="{{URL::to('/')}}/template/dist/js/jquery.nicescroll.js" type="text/javascript"></script><!--custome script for all page-->
    <script src="{{URL::to('/')}}/template/dist/js/scripts.js"></script>
    <script type="text/javascript" src="{{URL::to('/')}}/template/assets/ckeditor/ckeditor.js"></script>
    <!-- DataTables -->
    <script src="{{URL::to('/')}}/template/plugins/datatables/jquery.dataTables.min.js"></script>
     <script src="{{URL::to('/')}}/template/plugins/datatables/dataTables.bootstrap.min.js"> </script>
    <script>
      $(function () {
        $("#example1").DataTable();
        $('#example2').DataTable({
          "paging": true,
          "lengthChange": true,
          "searching": true,
          "ordering": true,
          "info": true,
          "autoWidth": true
        });
      });
    </script>

  

<div id="ascrail2000" class="nicescroll-rails" style="width: 6px; z-index: 1000; cursor: default; position: fixed; top: 0px; height: 100%; right: 0px; display: none; background: rgb(247, 247, 247);"><div style="position: relative; top: 0px; float: right; width: 6px; height: 0px; border-radius: 10px; background-color: rgb(0, 122, 255); background-clip: padding-box;"></div></div><div id="ascrail2000-hr" class="nicescroll-rails" style="height: 6px; z-index: 1000; position: fixed; left: 0px; width: 100%; bottom: 0px; cursor: default; display: none; background: rgb(247, 247, 247);"><div style="position: relative; top: 0px; height: 6px; width: 0px; border-radius: 10px; background-color: rgb(0, 122, 255); background-clip: padding-box;"></div></div></body></html>