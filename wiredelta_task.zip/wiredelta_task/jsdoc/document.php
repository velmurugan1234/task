Language Details:
	PHP-Laravel 4.2 Framework.
	phpMyAdmin-MYSQL 5.0.
Database Details:
	DB name: wiredelta
	Table  name: samples
	Model name: Sample

1)Execution url: http://localhost/wiredelta_task/public/
2)Click Add New button in right corner.

VALIDATION:
	The Validation can be performed using model class.
3)Without data in form click save button at bottom of the form page.
	->Required error message can be displayed all individual fields.
		i) InTextbox field minlength:4 and maxlength:10.
		ii) In Textarea field minlength:10 and maxlength:255.
		iii) In Email field required and The email must be a valid email address.
		iv) In URL field required and please enter url validation.
		v) In Number field only enter numeric values and minvalue:4 and maxvalue:10.
		vi) In password field required and minlength:6 and maxlenght:10.
		vii) In Confirm passfield required and password and confirm password filed must be same.
		Viii) In Radiobox, Checkbox and Selectbox field is required.

4) After form validation the data can be add to database table and displayed in homepage.
5) If the user can edit and delete table data's.

